#!/bin/bash

/usr/local/bin/dronekit-sitl copter --home=-15.839586,-47.927183,1000,0&

sleep 5

#/usr/bin/qground.AppImage 2>/dev/null&

#usr/bin/apmplanner2 2>/dev/null&

sleep 5

screen -dm mavproxy.py --master=tcp:127.0.0.1:5760 --out=127.0.0.1:14550 --out=127.0.0.1:5762

/usr/bin/python "$1" --connect 127.0.0.1:5762

function finish {
	#kill -9 $(ps -eF | grep QG | awk -F ' ' '{print $2}')
	kill -9 $(ps -eF | grep ardu | awk -F ' ' '{print $2}')
	kill -9 $(ps -eF | grep mav | awk -F ' ' '{print $2}')
}


trap finish EXIT

killall dronekit-sitl
killall mavproxy.py
killall python
killall apm
killall apmplanner2
